<?php
if(!isset($_SESSION["tblname"]))
{
	header("location:../index.php");
}
?>