<?php
unset($_SESSION["tblname"]); //session estblishedemnet
header('Location:index.php');
?>