# PHP CRUD w/ MySQL DB
## El objetivo de esta app contiene las operaciones básicas:
- Create (Crear registros)
- Read OR Retrieve (Leer registros)
- Update (Actualizar registros)
- Delete OR Destroy (Borrar registros)

### La BD contiene las prácticas del archivo style.css que es una modificación de bootstrap e ir mejorando la apariencia del index.html

### No hay framework, es una app simple en PHP
